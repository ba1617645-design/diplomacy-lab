// =============================================
//  Supabase client - يستخدم fetch مباشر
//  خفيف وسريع وما يسبب مشاكل في التحميل
// =============================================

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL || '';
const SUPABASE_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY || '';
export const isReady = !!(SUPABASE_URL && SUPABASE_KEY);
export function isSupabaseReady() { return isReady; }

function headers() {
  return {
    'Content-Type': 'application/json',
    'apikey': SUPABASE_KEY,
    'Authorization': `Bearer ${SUPABASE_KEY}`,
  };
}

// ====== Auth ======
export async function signUp(email: string, password: string, profile: any) {
  if (!isReady) return { user: null, error: 'Supabase not configured' };
  
  // 1. Create auth user
  const res1 = await fetch(`${SUPABASE_URL}/auth/v1/signup`, {
    method: 'POST',
    headers: headers(),
    body: JSON.stringify({ email, password, data: {} }),
  });
  const data1 = await res1.json();
  if (!res1.ok) throw new Error(data1.msg || data1.error || 'Registration failed');
  
  // 2. Insert profile
  if (data1.id) {
    await fetch(`${SUPABASE_URL}/rest/v1/profiles`, {
      method: 'POST',
      headers: headers(),
      body: JSON.stringify({
        id: data1.id,
        email,
        full_name: profile.full_name,
        phone: profile.phone || '',
        country: profile.country || '',
        profession: profile.profession || '',
        role: profile.role || 'participant',
      }),
    });
  }
  
  return { user: data1 };
}

export async function signIn(email: string, password: string) {
  if (!isReady) throw new Error('Supabase not configured');
  
  const res = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=password`, {
    method: 'POST',
    headers: headers(),
    body: JSON.stringify({ email, password }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.msg || data.error_description || data.error || 'Login failed');
  
  return { user: data.user || data };
}

// ====== Profiles ======
export async function getProfile(userId: string) {
  if (!isReady) return null;
  const res = await fetch(`${SUPABASE_URL}/rest/v1/profiles?id=eq.${userId}`, {
    headers: headers(),
  });
  const data = await res.json();
  return data?.[0] || null;
}

export async function getAllProfiles() {
  if (!isReady) return [];
  const res = await fetch(`${SUPABASE_URL}/rest/v1/profiles?order=created_at.desc`, {
    headers: headers(),
  });
  const data = await res.json();
  return data || [];
}

export async function updateProfile(userId: string, updates: any) {
  if (!isReady) return;
  await fetch(`${SUPABASE_URL}/rest/v1/profiles?id=eq.${userId}`, {
    method: 'PATCH',
    headers: headers(),
    body: JSON.stringify(updates),
  });
}

// ====== Activities ======
export async function getActivities() {
  if (!isReady) return [];
  const res = await fetch(`${SUPABASE_URL}/rest/v1/activities?order=id.asc`, {
    headers: headers(),
  });
  return (await res.json()) || [];
}

export async function toggleActivityLock(dayKey: string, isLocked: boolean) {
  if (!isReady) return;
  await fetch(`${SUPABASE_URL}/rest/v1/activities?day_key=eq.${dayKey}`, {
    method: 'PATCH',
    headers: headers(),
    body: JSON.stringify({ is_locked: isLocked }),
  });
}

// ====== Trainer Profile ======
export async function getTrainerProfile() {
  if (!isReady) return null;
  const res = await fetch(`${SUPABASE_URL}/rest/v1/trainer_profile?id=eq.1`, {
    headers: headers(),
  });
  const data = await res.json();
  return data?.[0] || null;
}

export async function updateTrainerProfile(updates: any) {
  if (!isReady) return;
  await fetch(`${SUPABASE_URL}/rest/v1/trainer_profile?id=eq.1`, {
    method: 'PATCH',
    headers: headers(),
    body: JSON.stringify(updates),
  });
}
